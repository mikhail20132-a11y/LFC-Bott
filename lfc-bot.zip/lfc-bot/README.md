# ⚽ Legacy Football Championship — Discord Bot

A complete league management Discord bot for the **Legacy Football Championship (LFC)**, a Roblox football league. Built with TypeScript, Discord.js v14, PostgreSQL, and Prisma.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Fill in DISCORD_TOKEN, CLIENT_ID, GUILD_ID, DATABASE_URL

# 3. Generate Prisma client
npm run prisma:generate

# 4. Push schema to database
npm run prisma:push

# 5. Deploy slash commands to Discord
npm run deploy:commands

# 6. Start the bot
npm run dev
```

---

## 📋 Command Reference

### 👤 Player System
| Command | Description | Permission |
|---------|-------------|------------|
| `/player profile <player>` | Full player profile with stats, awards, transfers | Everyone |
| `/player stats <player>` | Detailed career stat breakdown per season | Everyone |
| `/leaderboard [type]` | Top goalscorers, assists, MVPs, appearances | Everyone |

### 🏟️ Team System
| Command | Description | Permission |
|---------|-------------|------------|
| `/team create <name>` | Register a new team | Founder / League Management |
| `/team info <name>` | View team details and season record | Everyone |
| `/team roster <name>` | View squad list by position | Everyone |
| `/team stats <name>` | Season-by-season stats breakdown | Everyone |

### ⚽ Match System
| Command | Description | Permission |
|---------|-------------|------------|
| `/match create <home> <away>` | Schedule a match | Founder / Management / Referee |
| `/match start <match_id>` | Begin a scheduled match | Founder / Management / Referee |
| `/match report <match_id> <event> <player>` | Record goals, assists, cards, MVP | Founder / Management / Referee |
| `/match finish <match_id> <home_score> <away_score>` | End match, update standings | Founder / Management / Referee |

### 🏆 League System
| Command | Description | Permission |
|---------|-------------|------------|
| `/standings` | Current league table sorted by points | Everyone |
| `/fixtures` | Upcoming scheduled matches | Everyone |
| `/results` | Recent match results with scorers & MVP | Everyone |
| `/history <team1> <team2>` | Head-to-head record between teams | Everyone |

### 🏅 Awards System
| Command | Description | Permission |
|---------|-------------|------------|
| `/award give <type> <player>` | Give a season award | Founder / League Management |

### 🔄 Transfer System
| Command | Description | Permission |
|---------|-------------|------------|
| `/transfer create <player> <to_team> [fee]` | Create transfer request | Founder / League Management |
| `/transfer complete <transfer_id>` | Finalize transfer | Founder / League Management |
| `/transfers` | View recent completed transfers | Everyone |

### 📰 News & Media System (Auto-Posting)
| Command | Description | Permission |
|---------|-------------|------------|
| `/news setchannel <channel>` | Set the auto-news broadcast channel | Founder / League Management |
| `/news latest [count]` | View recent news articles | Everyone |
| `/news broadcast <title> <message>` | Send breaking news | Founder / League Management |
| `/news roundup` | Generate weekly league roundup | Founder / League Management |

### 🛠️ Admin System
| Command | Description | Permission |
|---------|-------------|------------|
| `/setup` | Bot setup guide and checklist | Founder |
| `/season start <name>` | Begin a new season | Founder / League Management |
| `/season end` | End current season with champion | Founder / League Management |
| `/warn <user> <reason>` | Issue a warning | Founder / Management / Moderator |
| `/suspend <user> <reason> [duration]` | Suspend a user | Founder / League Management |
| `/blacklist <user> <reason>` | Permanently blacklist | Founder |

---

## 📡 Auto News System

The bot automatically posts to your configured news channel when:

| Event | News Type | Auto-Posted |
|-------|-----------|-------------|
| ✅ Match finished | ⚽ Match Result | Score, scorers, MVP, links |
| ✅ Transfer completed | 🔄 Transfer Announcement | Player, teams, fee |
| ✅ Award given | 🏅 Award Ceremony | Player, award type, season |
| ✅ Season started | 📅 Season Begins | Season name, teams count |
| ✅ Season ended | 🏆 Season Ends | Champion crowning |
| 🌟 Player milestones | 🎯 Milestone Reached | 10/25/50 goals, 50/100 apps, etc. |

Plus manual broadcasts via `/news broadcast` and `/news roundup`.

---

## 🗄️ Database Schema (15 Models)

```
DiscordUser ──┬── Player ──┬── PlayerSeasonStats
              │             ├── Award
              │             ├── Transfer (from/to)
              │             ├── MatchGoal
              │             ├── MatchAssist
              │             ├── MatchMvp
              │             └── MatchCard
              │
              ├── Team (manager) ──┬── TeamSeasonStats
              │                    ├── Player[]
              │                    ├── Match (home)
              │                    └── Match (away)
              │
              ├── Warning
              ├── Suspension
              ├── Blacklist
              ├── GuildConfig
              └── NewsArticle

Season ──┬── Match
         ├── PlayerSeasonStats
         ├── TeamSeasonStats
         └── Award
```

---

## 🏗️ Project Structure

```
lfc-bot/
├── prisma/
│   └── schema.prisma          # Database schema (15 models)
├── src/
│   ├── index.ts               # Bot entry point
│   ├── deploy-commands.ts     # Slash command registration
│   ├── commands/
│   │   ├── admin/             # Setup, warn, suspend, blacklist, season
│   │   ├── award/             # Give awards
│   │   ├── league/            # Standings, fixtures, results, history
│   │   ├── match/             # Create, start, report, finish
│   │   ├── news/              # Setchannel, latest, broadcast, roundup
│   │   ├── player/            # Profile, stats, leaderboard
│   │   ├── team/              # Create, info, roster, stats
│   │   └── transfer/          # Create, complete, list
│   ├── database/
│   │   └── prisma.ts          # Prisma client singleton
│   ├── events/
│   │   ├── ready.ts           # Bot online
│   │   └── interactionCreate.ts # Command handler with cooldowns
│   ├── services/
│   │   ├── playerService.ts   # Player CRUD & leaderboards
│   │   ├── teamService.ts     # Team management
│   │   ├── matchService.ts    # Match lifecycle & stats
│   │   ├── leagueService.ts   # Seasons & standings
│   │   ├── adminService.ts    # Warnings, suspensions, blacklists
│   │   └── newsService.ts     # Auto-news, milestones, broadcasts
│   ├── types/
│   │   └── index.ts           # TypeScript interfaces & types
│   └── utils/
│       ├── commandLoader.ts   # Dynamic command loading
│       ├── eventLoader.ts     # Dynamic event loading
│       ├── helpers.ts         # Embed builders, formatters
│       └── permissions.ts     # Role-based access control
├── .env.example
├── package.json
└── tsconfig.json
```

---

## 🔐 Permission System

| Role | Access Level |
|------|-------------|
| **Founder** | Full access — setup, season control, blacklist, all commands |
| **League Management** | Operations — create teams/matches, transfers, awards, broadcast |
| **Moderator** | Moderation — warnings only |
| **Referee** | Match operations — create, start, report, finish matches |

Roles are matched by name (case-insensitive). Create the corresponding roles in your Discord server.

---

## 📦 Dependencies

- **discord.js** ^14.18 — Discord API
- **@prisma/client** ^6.6 — Database ORM
- **prisma** ^6.6 (dev) — Schema management
- **typescript** ^5.7 (dev) — Type checking
- **tsx** ^4.19 (dev) — Dev runner
- **dotenv** ^16.4 — Environment variables

---

## 🧪 Development

```bash
# Watch mode
npm run dev

# Build for production
npm run build

# Start production build
npm start

# Database studio (GUI)
npm run prisma:studio

# Create migration after schema changes
npm run prisma:migrate

# Deploy commands to Discord
npm run deploy:commands
```

---

Built for **Legacy Football Championship** ⚽