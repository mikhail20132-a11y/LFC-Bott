import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { adminService } from "../../services/adminService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed, formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a user for misconduct (Staff only)")
    .addUserOption((opt) =>
      opt
        .setName("user")
        .setDescription("User to warn")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("reason")
        .setDescription("Reason for the warning")
        .setRequired(true)
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply({ ephemeral: true });

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement) &&
      !hasRole(member as never, RoleType.Moderator)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder**, **League Management**, or **Moderator** role."
          ),
        ],
      });
      return;
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);

    try {
      await adminService.warnUser(targetUser.id, reason, interaction.user.id);

      const embed = new EmbedBuilder()
        .setTitle("⚠️ Warning Issued")
        .setColor("#FFAA00")
        .addFields(
          { name: "👤 User", value: `<@${targetUser.id}>`, inline: true },
          { name: "📝 Reason", value: reason, inline: false },
          { name: "👮‍♂️ Issued By", value: `<@${interaction.user.id}>`, inline: true }
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

      // Try to DM the warned user
      try {
        const dmEmbed = new EmbedBuilder()
          .setTitle("⚠️ You have received a warning")
          .setColor("#FFAA00")
          .addFields(
            { name: "Server", value: interaction.guild?.name ?? "LFC", inline: true },
            { name: "Reason", value: reason, inline: false }
          )
          .setFooter({ text: "Legacy Football Championship" })
          .setTimestamp();

        await targetUser.send({ embeds: [dmEmbed] });
      } catch {
        // User may have DMs disabled, that's fine
      }
    } catch (error) {
      console.error("[Warn Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while issuing the warning.",
      });
    }
  },
};

export default command;