import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { adminService } from "../../services/adminService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("suspend")
    .setDescription("Suspend a user from the league (Management only)")
    .addUserOption((opt) =>
      opt
        .setName("user")
        .setDescription("User to suspend")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("reason")
        .setDescription("Reason for the suspension")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("duration")
        .setDescription("Suspension duration (e.g. 7d, 30d, permanent)")
        .setRequired(false)
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply({ ephemeral: true });

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder** or **League Management** role."
          ),
        ],
      });
      return;
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);
    const duration = interaction.options.getString("duration");

    try {
      // Parse duration
      let expiresAt: Date | undefined;
      if (duration && duration !== "permanent") {
        const match = duration.match(/^(\d+)(d|h|m)$/);
        if (match) {
          const amount = parseInt(match[1]);
          const unit = match[2];
          const now = new Date();
          switch (unit) {
            case "m":
              expiresAt = new Date(now.getTime() + amount * 60000);
              break;
            case "h":
              expiresAt = new Date(now.getTime() + amount * 3600000);
              break;
            case "d":
              expiresAt = new Date(now.getTime() + amount * 86400000);
              break;
          }
        }
      }

      await adminService.suspendUser(
        targetUser.id,
        reason,
        interaction.user.id,
        expiresAt
      );

      const embed = new EmbedBuilder()
        .setTitle("🔒 User Suspended")
        .setColor("#FF0000")
        .addFields(
          { name: "👤 User", value: `<@${targetUser.id}>`, inline: true },
          { name: "📝 Reason", value: reason, inline: false },
          {
            name: "⏱ Duration",
            value: expiresAt ? `Until ${expiresAt.toLocaleDateString()}` : "Permanent",
            inline: true,
          },
          {
            name: "👮‍♂️ Issued By",
            value: `<@${interaction.user.id}>`,
            inline: true,
          }
        )
        .setFooter({ text: "Use /suspend again to extend | Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Suspend Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while suspending the user.",
      });
    }
  },
};

export default command;