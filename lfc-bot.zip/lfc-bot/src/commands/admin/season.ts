import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { leagueService } from "../../services/leagueService.js";
import { newsService } from "../../services/newsService.js";
import { teamService } from "../../services/teamService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command, ExtendedClient } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("season")
    .setDescription("Season management commands")
    .addSubcommand((sub) =>
      sub
        .setName("start")
        .setDescription("Start a new season (Management only)")
        .addStringOption((opt) =>
          opt
            .setName("name")
            .setDescription("Season name (e.g. Season 3)")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("end")
        .setDescription("End the current active season (Management only)")
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder** or **League Management** role."
          ),
        ],
      });
      return;
    }

    const subcommand = interaction.options.getSubcommand();
    const client = interaction.client as ExtendedClient;

    try {
      if (subcommand === "start") {
        await handleSeasonStart(interaction, client);
      } else if (subcommand === "end") {
        await handleSeasonEnd(interaction, client);
      }
    } catch (error) {
      console.error("[Season Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred managing the season.",
      });
    }
  },
};

async function handleSeasonStart(interaction: CommandInteraction, client: ExtendedClient) {
  const name = interaction.options.getString("name", true);

  // Check for existing active season
  const active = await leagueService.getActiveSeason();
  if (active) {
    await interaction.editReply({
      embeds: [
        createErrorEmbed(
          "❌ Season Already Active",
          `**${active.name}** is already active. End it first with \`/season end\`.`
        ),
      ],
    });
    return;
  }

  const season = await leagueService.createSeason(name);
  await leagueService.initializeSeasonStats(season.id);
  await leagueService.initializePlayerSeasonStats(season.id);

  // ── Auto-post season start news ──
  try {
    if (interaction.guild) {
      const teams = await teamService.listTeams();
      await newsService.announceSeasonStart(client, {
        guildId: interaction.guild.id,
        seasonName: season.name,
        teamCount: teams.length,
      });
    }
  } catch (newsError) {
    console.error("[Season News Error]", newsError);
  }

  const embed = new EmbedBuilder()
    .setTitle("📅 New Season Started!")
    .setColor("#00AA00")
    .setDescription(`**${season.name}** is now active!`)
    .addFields(
      { name: "📋 Season", value: season.name, inline: true },
      { name: "🎯 Status", value: "🟢 Active", inline: true },
      {
        name: "✅ What's Next?",
        value: [
          "1. Make sure all teams are registered with `/team create`",
          "2. Schedule matches with `/match create`",
          "3. Use `/standings` to track the league table",
        ].join("\n"),
        inline: false,
      }
    )
    .setFooter({ text: "Legacy Football Championship" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}

async function handleSeasonEnd(interaction: CommandInteraction, client: ExtendedClient) {
  const active = await leagueService.getActiveSeason();
  if (!active) {
    await interaction.editReply({
      embeds: [createErrorEmbed("❌ No Active Season", "There is no active season to end.")],
    });
    return;
  }

  // Get final standings
  const standings = await leagueService.getStandings(active.id);
  const champion = standings[0];

  const ended = await leagueService.endActiveSeason();

  // ── Auto-post season end news ──
  try {
    if (interaction.guild) {
      await newsService.announceSeasonEnd(client, {
        guildId: interaction.guild.id,
        seasonName: active.name,
        championName: champion?.teamName,
        championPoints: champion?.points,
      });
    }
  } catch (newsError) {
    console.error("[Season News Error]", newsError);
  }

  const embed = new EmbedBuilder()
    .setTitle("🏆 Season Ended!")
    .setColor("#FFD700")
    .setDescription(`**${active.name}** has come to a close!`);

  if (champion) {
    embed.addFields({
      name: "👑 Champions",
      value: `**${champion.teamName}** — ${champion.points}pts (${champion.wins}W / ${champion.draws}D / ${champion.losses}L)`,
      inline: false,
    });
  }

  embed
    .addFields(
      { name: "📋 Season", value: active.name, inline: true },
      { name: "✅ Status", value: "🔴 Ended", inline: true },
      {
        name: "🎯 Next Steps",
        value: "Use `/award give` to distribute season awards, then `/season start` to begin a new season.",
        inline: false,
      }
    )
    .setFooter({ text: "Legacy Football Championship" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });
}

export default command;