import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { adminService } from "../../services/adminService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("blacklist")
    .setDescription("Blacklist a user from the league (Founder only)")
    .addUserOption((opt) =>
      opt
        .setName("user")
        .setDescription("User to blacklist")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("reason")
        .setDescription("Reason for blacklisting")
        .setRequired(true)
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply({ ephemeral: true });

    if (!hasRole(interaction.member as never, RoleType.Founder)) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only the **Founder** can blacklist users."
          ),
        ],
      });
      return;
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);

    try {
      const isBlacklisted = await adminService.isBlacklisted(targetUser.id);
      if (isBlacklisted) {
        await interaction.editReply({
          embeds: [
            createErrorEmbed(
              "❌ Already Blacklisted",
              `${targetUser.username} is already blacklisted.`
            ),
          ],
        });
        return;
      }

      await adminService.blacklistUser(targetUser.id, reason, interaction.user.id);

      const embed = new EmbedBuilder()
        .setTitle("🚫 User Blacklisted")
        .setColor("#000000")
        .addFields(
          { name: "👤 User", value: `<@${targetUser.id}>`, inline: true },
          { name: "📝 Reason", value: reason, inline: false },
          { name: "👮‍♂️ Issued By", value: `<@${interaction.user.id}>`, inline: true }
        )
        .setFooter({ text: "This action is irreversible | Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Blacklist Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while blacklisting the user.",
      });
    }
  },
};

export default command;