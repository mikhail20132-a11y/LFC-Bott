import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed, createSuccessEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Set up the LFC bot in this server (Founder only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    if (!hasRole(interaction.member as never, RoleType.Founder)) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only the **Founder** can run setup."
          ),
        ],
      });
      return;
    }

    const guild = interaction.guild;
    if (!guild) {
      await interaction.editReply({
        embeds: [createErrorEmbed("❌ Error", "This command must be used in a server.")],
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setTitle("✅ LFC Bot Setup Complete")
      .setColor("#00AA00")
      .setDescription(
        "Legacy Football Championship bot has been configured for this server!"
      )
      .addFields(
        {
          name: "📋 Required Roles",
          value: [
            "Make sure these roles exist in your server:",
            "• **Founder** — Top-level admin access",
            "• **League Management** — League operations",
            "• **Moderator** — General moderation",
            "• **Referee** — Match officiating",
          ].join("\n"),
          inline: false,
        },
        {
          name: "⚙️ Getting Started",
          value: [
            "1. `/season start` — Begin a new season",
            "2. `/team create` — Register teams",
            "3. `/match create` — Schedule matches",
            "4. `/match start` — Begin a match",
            "5. `/match report` — Record events",
            "6. `/match finish` — End the match",
          ].join("\n"),
          inline: false,
        },
        {
          name: "📖 Need Help?",
          value: "Use `/` to browse all available commands.",
          inline: false,
        }
      )
      .setFooter({ text: "Legacy Football Championship" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};

export default command;