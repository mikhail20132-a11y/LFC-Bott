import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { newsService } from "../../services/newsService.js";
import type { Command } from "../../types/index.js";

const TYPE_EMOJIS: Record<string, string> = {
  match_result: "⚽",
  transfer: "🔄",
  award: "🏅",
  season_start: "📅",
  season_end: "🏆",
  milestone: "🌟",
  broadcast: "📢",
  weekly_roundup: "📊",
};

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("news")
    .setDescription("News commands")
    .addSubcommand((sub) =>
      sub
        .setName("latest")
        .setDescription("View the latest LFC news and announcements")
        .addIntegerOption((opt) =>
          opt
            .setName("count")
            .setDescription("Number of articles to show (1-20)")
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(20)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const count = interaction.options.getInteger("count") ?? 5;
    const guildId = interaction.guild?.id;
    if (!guildId) return;

    try {
      const articles = await newsService.getRecentNews(guildId, count);

      const embed = new EmbedBuilder()
        .setTitle("📰 Latest LFC News")
        .setColor("#00AA00");

      if (articles.length > 0) {
        embed.setDescription(
          articles
            .map(
              (a, i) =>
                `${i + 1}. ${TYPE_EMOJIS[a.type] ?? "📰"} **${a.title}**\n` +
                `   ${a.content.slice(0, 100)}${a.content.length > 100 ? "..." : ""}\n` +
                `   🕐 <t:${Math.floor(a.createdAt.getTime() / 1000)}:R>`
            )
            .join("\n\n")
        );
      } else {
        embed.setDescription("No news articles yet. As matches happen, transfers complete, and awards are given, they'll appear here automatically!");
      }

      embed
        .setFooter({
          text: `Showing last ${articles.length || 0} articles • Legacy Football Championship`,
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[News Latest Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching news.",
      });
    }
  },
};

export default command;