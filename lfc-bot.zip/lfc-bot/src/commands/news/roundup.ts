import {
  SlashCommandBuilder,
  CommandInteraction,
} from "discord.js";
import { newsService } from "../../services/newsService.js";
import { leagueService } from "../../services/leagueService.js";
import { playerService } from "../../services/playerService.js";
import { matchService } from "../../services/matchService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("news")
    .setDescription("News commands")
    .addSubcommand((sub) =>
      sub
        .setName("roundup")
        .setDescription("Generate a weekly league roundup (Management only)")
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply({ ephemeral: true });

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder** or **League Management** role."
          ),
        ],
      });
      return;
    }

    const guildId = interaction.guild?.id;
    if (!guildId) return;

    try {
      const activeSeason = await leagueService.getActiveSeason();
      if (!activeSeason) {
        await interaction.editReply({
          content: "❌ No active season to generate a roundup for.",
        });
        return;
      }

      const standings = await leagueService.getStandings(activeSeason.id);
      const topScorers = await playerService.getTopGoalscorers(5);
      const results = await matchService.getRecentResults(5);

      const result = await newsService.generateWeeklyRoundup(
        interaction.client as never,
        guildId,
        activeSeason.name,
        standings.map((s) => ({
          position: s.position,
          teamName: s.teamName,
          played: s.played,
          wins: s.wins,
          draws: s.draws,
          losses: s.losses,
          points: s.points,
        })),
        topScorers.map((p) => ({
          name: p.user.username,
          goals: p.goals,
          team: p.team?.name,
        })),
        results.map((m) => ({
          homeTeam: m.homeTeam.name,
          awayTeam: m.awayTeam.name,
          homeScore: m.homeScore,
          awayScore: m.awayScore,
        }))
      );

      if (result) {
        await interaction.editReply({
          content: `✅ Weekly roundup published! [View post](${result.url})`,
        });
      } else {
        await interaction.editReply({
          content: "⚠️ Roundup generated but no news channel is configured. Use `/news setchannel` first.",
        });
      }
    } catch (error) {
      console.error("[Roundup Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while generating the roundup.",
      });
    }
  },
};

export default command;