import {
  SlashCommandBuilder,
  CommandInteraction,
  ChannelType,
  EmbedBuilder,
} from "discord.js";
import { newsService } from "../../services/newsService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("news")
    .setDescription("News and media commands")
    .addSubcommand((sub) =>
      sub
        .setName("setchannel")
        .setDescription("Set the news broadcast channel (Management only)")
        .addChannelOption((opt) =>
          opt
            .setName("channel")
            .setDescription("The text channel for news broadcasts")
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder** or **League Management** role."
          ),
        ],
      });
      return;
    }

    const channel = interaction.options.getChannel("channel", true);
    if (!interaction.guild) return;

    await newsService.setNewsChannel(interaction.guild.id, channel.id);

    const embed = new EmbedBuilder()
      .setTitle("📢 News Channel Configured!")
      .setColor("#00AA00")
      .setDescription(
        `All auto-news will now be posted in ${channel}.`
      )
      .addFields(
        { name: "📺 Channel", value: `${channel}`, inline: true },
        {
          name: "📋 Auto-Posts Include",
          value: [
            "• ⚽ Match results & highlights",
            "• 🔄 Transfer announcements",
            "• 🏅 Award ceremonies",
            "• 📅 Season start/end",
            "• 🌟 Player milestones",
            "• 📊 Weekly roundups",
            "• 📢 Breaking broadcasts",
          ].join("\n"),
          inline: false,
        }
      )
      .setFooter({ text: "Legacy Football Championship • News System" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};

export default command;