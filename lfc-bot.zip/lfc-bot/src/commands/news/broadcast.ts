import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { newsService } from "../../services/newsService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("news")
    .setDescription("News commands")
    .addSubcommand((sub) =>
      sub
        .setName("broadcast")
        .setDescription("Send a breaking news broadcast (Management only)")
        .addStringOption((opt) =>
          opt
            .setName("title")
            .setDescription("Broadcast headline")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("message")
            .setDescription("Broadcast message content")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("color")
            .setDescription("Embed color (red, blue, green, gold)")
            .setRequired(false)
            .addChoices(
              { name: "🔴 Red (Urgent)", value: "#FF0000" },
              { name: "🔵 Blue (Info)", value: "#0066FF" },
              { name: "🟢 Green (Positive)", value: "#00AA00" },
              { name: "🟡 Gold (Important)", value: "#FFD700" }
            )
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply({ ephemeral: true });

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only **Founder** or **League Management** can broadcast."
          ),
        ],
      });
      return;
    }

    const title = interaction.options.getString("title", true);
    const message = interaction.options.getString("message", true);
    const color = interaction.options.getString("color") ?? "#FF0000";

    if (!interaction.guild?.id) return;

    try {
      const result = await newsService.announceBroadcast(
        interaction.client as never,
        {
          guildId: interaction.guild.id,
          title,
          message,
          authorName: interaction.user.username,
          color,
        }
      );

      if (result) {
        await interaction.editReply({
          content: `✅ Broadcast sent! [View message](${result.url})`,
        });
      } else {
        await interaction.editReply({
          content: "⚠️ Broadcast published but no news channel is configured. Use `/news setchannel` first.",
        });
      }
    } catch (error) {
      console.error("[Broadcast Error]", error);
      await interaction.editReply({
        content: "❌ Failed to send broadcast. Make sure a news channel is set via `/news setchannel`.",
      });
    }
  },
};

export default command;