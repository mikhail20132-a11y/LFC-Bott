import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("match")
    .setDescription("Match commands")
    .addSubcommand((sub) =>
      sub
        .setName("report")
        .setDescription("Report match events (goal, assist, card, MVP)")
        .addStringOption((opt) =>
          opt
            .setName("match_id")
            .setDescription("Match ID")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("event")
            .setDescription("Event type")
            .setRequired(true)
            .addChoices(
              { name: "⚽ Goal", value: "goal" },
              { name: "🎯 Assist", value: "assist" },
              { name: "🟨 Yellow Card", value: "yellow" },
              { name: "🟥 Red Card", value: "red" },
              { name: "🏆 MVP", value: "mvp" }
            )
        )
        .addUserOption((opt) =>
          opt
            .setName("player")
            .setDescription("Player involved")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("minute")
            .setDescription("Minute of the event")
            .setRequired(false)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement) &&
      !hasRole(member as never, RoleType.Referee)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only staff can report match events."
          ),
        ],
      });
      return;
    }

    const matchId = interaction.options.getString("match_id", true);
    const eventType = interaction.options.getString("event", true);
    const targetUser = interaction.options.getUser("player", true);
    const minute = interaction.options.getString("minute");
    const minuteNum = minute ? parseInt(minute) : undefined;

    // Note: In production, you'd import playerService to resolve the player ID
    // For now we output the event as a logged message
    const eventEmojis: Record<string, string> = {
      goal: "⚽",
      assist: "🎯",
      yellow: "🟨",
      red: "🟥",
      mvp: "🏆",
    };

    const embed = new EmbedBuilder()
      .setTitle(`${eventEmojis[eventType] ?? "📋"} Match Event Reported`)
      .setColor("#00AA00")
      .addFields(
        { name: "🔢 Match ID", value: matchId.slice(0, 8), inline: true },
        { name: "📋 Event", value: eventType.toUpperCase(), inline: true },
        { name: "👤 Player", value: `<@${targetUser.id}>`, inline: true },
        { name: "⏱ Minute", value: minute ?? "N/A", inline: true },
        { name: "📝 Reported By", value: `<@${interaction.user.id}>`, inline: true }
      )
      .setFooter({ text: "Use /match finish to end the match" })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};

export default command;