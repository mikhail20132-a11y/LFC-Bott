import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("match")
    .setDescription("Match commands")
    .addSubcommand((sub) =>
      sub
        .setName("start")
        .setDescription("Start a scheduled match")
        .addStringOption((opt) =>
          opt
            .setName("match_id")
            .setDescription("Match ID to start")
            .setRequired(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement) &&
      !hasRole(member as never, RoleType.Referee)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only staff can start matches."
          ),
        ],
      });
      return;
    }

    const matchId = interaction.options.getString("match_id", true);

    try {
      const match = await matchService.startMatch(matchId);

      const embed = new EmbedBuilder()
        .setTitle("⚽ Match Started!")
        .setColor("#FFAA00")
        .setDescription(
          `**${match.homeTeamId}** vs **${match.awayTeamId}** is now **LIVE**!`
        )
        .addFields(
          { name: "🟢 Status", value: "Live", inline: true },
          { name: "🔢 Match ID", value: match.id.slice(0, 8), inline: true }
        )
        .setFooter({ text: "Use /match report to record goals, assists, and cards" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Match Start Error]", error);
      await interaction.editReply({
        content: "❌ Match not found or could not be started.",
      });
    }
  },
};

export default command;