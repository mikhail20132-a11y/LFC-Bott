import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import { leagueService } from "../../services/leagueService.js";
import { teamService } from "../../services/teamService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed, formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("match")
    .setDescription("Match management commands")
    .addSubcommand((sub) =>
      sub
        .setName("create")
        .setDescription("Schedule a new match (Management/Referee only)")
        .addStringOption((opt) =>
          opt
            .setName("home")
            .setDescription("Home team name")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("away")
            .setDescription("Away team name")
            .setRequired(true)
        )
        .addUserOption((opt) =>
          opt
            .setName("referee")
            .setDescription("Match referee")
            .setRequired(false)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement) &&
      !hasRole(member as never, RoleType.Referee)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need **Founder**, **League Management**, or **Referee** role to create matches."
          ),
        ],
      });
      return;
    }

    const homeName = interaction.options.getString("home", true);
    const awayName = interaction.options.getString("away", true);
    const refereeUser = interaction.options.getUser("referee");

    try {
      const homeTeam = await teamService.getTeamByName(homeName);
      const awayTeam = await teamService.getTeamByName(awayName);

      if (!homeTeam) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Team Not Found", `Home team **${homeName}** not found.`)],
        });
        return;
      }

      if (!awayTeam) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Team Not Found", `Away team **${awayName}** not found.`)],
        });
        return;
      }

      if (homeTeam.id === awayTeam.id) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Invalid Match", "A team cannot play against itself.")],
        });
        return;
      }

      const activeSeason = await leagueService.getActiveSeason();
      if (!activeSeason) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ No Active Season", "Please start a season first using `/season start`.")],
        });
        return;
      }

      const match = await matchService.createMatch({
        homeTeamId: homeTeam.id,
        awayTeamId: awayTeam.id,
        seasonId: activeSeason.id,
        refereeId: refereeUser?.id,
      });

      const embed = new EmbedBuilder()
        .setTitle("⚽ Match Scheduled")
        .setColor("#00AA00")
        .addFields(
          { name: "🏠 Home", value: homeTeam.name, inline: true },
          { name: "🆚", value: "vs", inline: true },
          { name: "🚗 Away", value: awayTeam.name, inline: true },
          { name: "📅 Season", value: activeSeason.name, inline: true },
          { name: "🔢 Match ID", value: match.id.slice(0, 8), inline: true },
          { name: "👨‍⚖️ Referee", value: refereeUser ? `<@${refereeUser.id}>` : "TBD", inline: true },
          { name: "📋 Status", value: "🟢 Scheduled", inline: false }
        )
        .setFooter({ text: "Use /match start to begin the match" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Match Create Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while creating the match.",
      });
    }
  },
};

export default command;