import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import { newsService } from "../../services/newsService.js";
import { prisma } from "../../database/prisma.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command, ExtendedClient } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("match")
    .setDescription("Match commands")
    .addSubcommand((sub) =>
      sub
        .setName("finish")
        .setDescription("Finish a match with the final score")
        .addStringOption((opt) =>
          opt
            .setName("match_id")
            .setDescription("Match ID to finish")
            .setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("home_score")
            .setDescription("Home team final score")
            .setRequired(true)
            .setMinValue(0)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("away_score")
            .setDescription("Away team final score")
            .setRequired(true)
            .setMinValue(0)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement) &&
      !hasRole(member as never, RoleType.Referee)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only staff can finish matches."
          ),
        ],
      });
      return;
    }

    const matchId = interaction.options.getString("match_id", true);
    const homeScore = interaction.options.getInteger("home_score", true);
    const awayScore = interaction.options.getInteger("away_score", true);

    try {
      const match = await matchService.finishMatch(matchId, {
        homeScore,
        awayScore,
      });

      // ── Auto-post match result news ──
      try {
        const fullMatch = await prisma.match.findUnique({
          where: { id: match.id },
          include: {
            homeTeam: true,
            awayTeam: true,
            goals: { include: { player: { include: { user: true } } } },
            mvps: { include: { player: { include: { user: true } } } },
          },
        });

        if (fullMatch && interaction.guild) {
          const scorers = fullMatch.goals.map(
            (g) => `${g.player.user.username}${g.minute ? ` (${g.minute}')` : ""}`
          );
          const mvp = fullMatch.mvps[0]?.player.user.username;

          await newsService.announceMatchResult(
            interaction.client as ExtendedClient,
            {
              guildId: interaction.guild.id,
              homeTeam: fullMatch.homeTeam.name,
              awayTeam: fullMatch.awayTeam.name,
              homeScore: fullMatch.homeScore,
              awayScore: fullMatch.awayScore,
              scorers,
              mvp,
              matchId: match.id,
            }
          );

          // Check milestones for all goal scorers and MVP
          for (const g of fullMatch.goals) {
            await newsService.checkMilestones(
              interaction.client as ExtendedClient,
              interaction.guild.id,
              g.playerId
            );
          }
          if (fullMatch.mvps[0]) {
            await newsService.checkMilestones(
              interaction.client as ExtendedClient,
              interaction.guild.id,
              fullMatch.mvps[0].playerId
            );
          }
        }
      } catch (newsError) {
        console.error("[Match News Error]", newsError);
        // Non-fatal — match result is still saved
      }

      const winnerText =
        homeScore > awayScore
          ? "🏠 **Home team wins!**"
          : awayScore > homeScore
            ? "🚗 **Away team wins!**"
            : "🤝 **It's a draw!**";

      const embed = new EmbedBuilder()
        .setTitle("✅ Match Finished!")
        .setColor("#00AA00")
        .setDescription(
          `**${match.homeTeamId}** ${match.homeScore} - ${match.awayScore} **${match.awayTeamId}**`
        )
        .addFields(
          { name: "📋 Result", value: winnerText, inline: false },
          { name: "🔢 Match ID", value: match.id.slice(0, 8), inline: true },
          { name: "📊 Status", value: "✅ Finished", inline: true }
        )
        .setFooter({
          text: "Standings have been updated | Legacy Football Championship",
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Match Finish Error]", error);
      await interaction.editReply({
        content: "❌ Failed to finish the match. Check the match ID.",
      });
    }
  },
};

export default command;