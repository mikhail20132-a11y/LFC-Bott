import {
  SlashCommandBuilder,
  CommandInteraction,
  AttachmentBuilder,
  EmbedBuilder,
} from "discord.js";
import { prisma } from "../../database/prisma.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";
import { createCanvas, loadImage, registerFont } from "canvas";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const POSITION_COLORS: Record<string, string> = {
  Goalkeeper: "#FFD700",
  Defender: "#00AAFF",
  Midfielder: "#00CC66",
  Forward: "#FF4444",
};

const RARITY_COLORS: Record<string, string> = {
  Common: "#888888",
  Rare: "#22AAFF",
  "Epic": "#AA44FF",
  Legendary: "#FFAA00",
};

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("card")
    .setDescription("Generate an EA FC style player card")
    .addUserOption((o) => o.setName("player").setDescription("Player").setRequired(true)),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const target = interaction.options.getUser("player", true);
    const player = await prisma.player.findUnique({
      where: { discordId: target.id },
      include: { user: true, team: true },
    });
    if (!player) {
      await interaction.editReply({ content: "❌ Player not registered." });
      return;
    }

    try {
      const width = 400;
      const height = 560;
      const canvas = createCanvas(width, height);
      const ctx = canvas.getContext("2d");

      // Background gradient
      const bgColor = POSITION_COLORS[player.position] ?? "#00AA00";
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, bgColor);
      grad.addColorStop(0.4, "#1a1a2e");
      grad.addColorStop(1, "#0f0f1a");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Card border
      ctx.strokeStyle = bgColor;
      ctx.lineWidth = 3;
      ctx.strokeRect(5, 5, width - 10, height - 10);

      // Top accent bar
      ctx.fillStyle = bgColor;
      ctx.fillRect(10, 10, width - 20, 4);

      // Rating circle
      const rating = Math.min(99, Math.max(60, player.goals * 3 + player.appearances + 60));
      ctx.beginPath();
      ctx.arc(80, 100, 40, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      ctx.fill();
      ctx.strokeStyle = bgColor;
      ctx.lineWidth = 3;
      ctx.stroke();

      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 36px Arial";
      ctx.textAlign = "center";
      ctx.fillText(`${rating}`, 80, 112);

      // Position label
      ctx.font = "bold 18px Arial";
      ctx.fillStyle = bgColor;
      ctx.textAlign = "left";
      const posAbbr: Record<string, string> = {
        Goalkeeper: "GK", Defender: "DEF", Midfielder: "MID", Forward: "FWD",
      };
      ctx.fillText(posAbbr[player.position] ?? "LFC", 140, 85);

      // Player name
      ctx.fillStyle = "#FFFFFF";
      ctx.font = "bold 24px Arial";
      ctx.fillText(target.username.length > 14 ? target.username.slice(0, 14) + "..." : target.username, 140, 115);

      // Stats
      const stats = [
        { label: "GOALS", value: player.goals, max: 50 },
        { label: "ASSISTS", value: player.assists, max: 50 },
        { label: "APPS", value: player.appearances, max: 100 },
        { label: "MVP", value: player.mvps, max: 20 },
      ];

      ctx.textAlign = "left";
      stats.forEach((stat, i) => {
        const y = 160 + i * 55;
        ctx.fillStyle = "#AAAAAA";
        ctx.font = "12px Arial";
        ctx.fillText(stat.label, 30, y);

        ctx.fillStyle = "#FFFFFF";
        ctx.font = "bold 28px Arial";
        ctx.fillText(`${stat.value}`, 30, y + 25);

        // Stat bar background
        ctx.fillStyle = "rgba(255,255,255,0.1)";
        ctx.fillRect(120, y + 10, 220, 8);
        // Stat bar fill
        const pct = Math.min(1, stat.value / stat.max);
        const barGrad = ctx.createLinearGradient(120, 0, 340, 0);
        barGrad.addColorStop(0, bgColor);
        barGrad.addColorStop(1, "#FFFFFF");
        ctx.fillStyle = barGrad;
        ctx.fillRect(120, y + 10, 220 * pct, 8);
      });

      // Club badge area
      if (player.team) {
        ctx.fillStyle = "rgba(255,255,255,0.1)";
        ctx.fillRect(30, 400, width - 60, 50);
        ctx.fillStyle = bgColor;
        ctx.font = "bold 16px Arial";
        ctx.textAlign = "center";
        ctx.fillText(player.team.name, width / 2, 430);
      }

      // LFC ID & footer
      ctx.fillStyle = "rgba(255,255,255,0.4)";
      ctx.font = "11px Arial";
      ctx.textAlign = "center";
      ctx.fillText(`LFC ID: ${player.lfcId}`, width / 2, 480);

      ctx.fillStyle = "rgba(255,255,255,0.2)";
      ctx.font = "10px Arial";
      ctx.fillText("LEGACY FOOTBALL CHAMPIONSHIP", width / 2, height - 30);

      // Bottom accent bar
      ctx.fillStyle = bgColor;
      ctx.fillRect(10, height - 14, width - 20, 4);

      // Convert to buffer
      const buffer = canvas.toBuffer("image/png");
      const attachment = new AttachmentBuilder(buffer, { name: `${target.username}-card.png` });

      await interaction.editReply({
        content: `🏆 **${target.username}** — EA FC Style Card`,
        files: [attachment],
      });
    } catch (error) {
      console.error("[Card Error]", error);
      await interaction.editReply({
        embeds: [createErrorEmbed("❌ Card Generation Failed", "Could not generate player card.")],
      });
    }
  },
};

export default command;