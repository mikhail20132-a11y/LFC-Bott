import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ComponentType,
} from "discord.js";
import { playerService } from "../../services/playerService.js";
import type { Command } from "../../types/index.js";

const LEADERBOARD_TYPES = [
  { label: "⚽ Top Goalscorers", value: "goals", emoji: "⚽" },
  { label: "🎯 Top Assists", value: "assists", emoji: "🎯" },
  { label: "🏆 Most MVPs", value: "mvps", emoji: "🏆" },
  { label: "📋 Most Appearances", value: "appearances", emoji: "📋" },
] as const;

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("View league leaderboards")
    .addStringOption((opt) =>
      opt
        .setName("type")
        .setDescription("Leaderboard category")
        .setRequired(false)
        .addChoices(
          { name: "⚽ Top Goalscorers", value: "goals" },
          { name: "🎯 Top Assists", value: "assists" },
          { name: "🏆 Most MVPs", value: "mvps" },
          { name: "📋 Most Appearances", value: "appearances" }
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const selectedType = interaction.options.getString("type") ?? "goals";

    try {
      await showLeaderboard(interaction, selectedType);
    } catch (error) {
      console.error("[Leaderboard Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching the leaderboard.",
      });
    }
  },
};

async function showLeaderboard(
  interaction: CommandInteraction,
  type: string
) {
  let players: Array<{
    user: { username: string; globalName: string | null };
    team: { name: string } | null;
    goals: number;
    assists: number;
    mvps: number;
    appearances: number;
  }>;
  let title: string;
  let valueKey: string;

  switch (type) {
    case "assists":
      players = await playerService.getTopAssists();
      title = "🎯 Top Assists";
      valueKey = "assists";
      break;
    case "mvps":
      players = await playerService.getTopMvps();
      title = "🏆 Most MVPs";
      valueKey = "mvps";
      break;
    case "appearances":
      players = await playerService.getTopAppearances();
      title = "📋 Most Appearances";
      valueKey = "appearances";
      break;
    default:
      players = await playerService.getTopGoalscorers();
      title = "⚽ Top Goalscorers";
      valueKey = "goals";
  }

  const embed = new EmbedBuilder()
    .setTitle(title)
    .setColor("#00AA00")
    .setDescription(
      players.length > 0
        ? players
            .map(
              (p, i) =>
                `${i + 1}. **${p.user.globalName ?? p.user.username}**` +
                `${p.team ? ` (${p.team.name})` : ""} — **${(p as Record<string, number>)[valueKey]}**`
            )
            .join("\n")
        : "No data available yet."
    )
    .setFooter({ text: "Legacy Football Championship" })
    .setTimestamp();

  // Add a select menu to switch leaderboard types
  const select = new StringSelectMenuBuilder()
    .setCustomId("leaderboard_select")
    .setPlaceholder("Switch leaderboard...")
    .addOptions(
      LEADERBOARD_TYPES.map((lt) => ({
        label: lt.label,
        value: lt.value,
      }))
    );

  const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    select
  );

  const reply = await interaction.editReply({
    embeds: [embed],
    components: [row],
  });

  // Handle select menu interaction
  const collector = reply.createMessageComponentCollector({
    componentType: ComponentType.StringSelect,
    time: 60_000,
  });

  collector.on("collect", async (selectInteraction) => {
    if (selectInteraction.user.id !== interaction.user.id) {
      await selectInteraction.reply({
        content: "❌ Only the command author can use this.",
        ephemeral: true,
      });
      return;
    }

    await selectInteraction.deferUpdate();
    await showLeaderboard(
      selectInteraction as unknown as CommandInteraction,
      selectInteraction.values[0]
    );
  });

  collector.on("end", async () => {
    const disabledRow =
      ActionRowBuilder.from<StringSelectMenuBuilder>(row);
    disabledRow.components.forEach((c) => c.setDisabled(true));

    await interaction.editReply({ components: [disabledRow] });
  });
}

export default command;