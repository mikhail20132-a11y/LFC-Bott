import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { playerService } from "../../services/playerService.js";
import { formatSeasonStats, formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("player")
    .setDescription("View a player's full profile")
    .addSubcommand((sub) =>
      sub
        .setName("profile")
        .setDescription("View a player profile")
        .addUserOption((opt) =>
          opt
            .setName("player")
            .setDescription("The player to look up")
            .setRequired(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const targetUser = interaction.options.getUser("player", true);

    try {
      const player = await playerService.getPlayer(targetUser.id);

      if (!player) {
        const embed = new EmbedBuilder()
          .setTitle("❌ Player Not Found")
          .setDescription(
            `${targetUser.username} is not registered as an LFC player yet. They need to play their first match to be registered.`
          )
          .setColor("#FF0000")
          .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      // Season stats display
      const seasonStatsText =
        player.seasonStats.length > 0
          ? player.seasonStats
              .map(
                (s) =>
                  `**${s.season.name}**: ⚽ ${s.goals}G | 🎯 ${s.assists}A | 🏆 ${s.mvps} MVP | 📋 ${s.appearances} Apps`
              )
              .join("\n")
          : "No season data yet.";

      // Career stats
      const careerStats = {
        goals: player.goals,
        assists: player.assists,
        mvps: player.mvps,
        appearances: player.appearances,
        yellowCards: player.yellowCards,
        redCards: player.redCards,
      };

      // Awards
      const awardsText =
        player.awards.length > 0
          ? player.awards
              .map((a) => `🏅 **${a.type}** — ${a.season.name}`)
              .join("\n")
          : "No awards yet.";

      // Transfers
      const transfers = await playerService.getTransferHistory(player.id);
      const transfersText =
        transfers.length > 0
          ? transfers
              .slice(0, 5)
              .map(
                (t) =>
                  `🔄 ${t.fromTeamName ?? "Free Agent"} → ${t.toTeamName ?? "Free Agent"}${t.fee ? ` ($${t.fee}M)` : ""}`
              )
              .join("\n")
          : "No transfer history.";

      const embed = new EmbedBuilder()
        .setTitle(`${targetUser.username} — LFC Profile`)
        .setThumbnail(targetUser.displayAvatarURL())
        .setColor("#00AA00")
        .addFields(
          {
            name: "👤 General",
            value: [
              `**LFC ID:** ${player.lfcId}`,
              `**Discord ID:** ${player.discordId}`,
              `**Joined:** ${formatDate(player.joinedAt)}`,
            ].join("\n"),
            inline: false,
          },
          {
            name: "⚽ Club & Position",
            value: [
              `**Club:** ${player.team?.name ?? "Free Agent"}`,
              `**Position:** ${player.position}`,
              `**Region:** ${player.region}`,
            ].join("\n"),
            inline: true,
          },
          {
            name: "🏆 Trophies & Awards",
            value: `**Trophies:** ${player.trophies}\n${awardsText}`,
            inline: true,
          },
          {
            name: "📊 Season Stats",
            value: seasonStatsText,
            inline: false,
          },
          {
            name: "📈 Career Stats",
            value: formatSeasonStats(careerStats),
            inline: false,
          },
          {
            name: "🔄 Transfer History",
            value: transfersText,
            inline: false,
          }
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Player Profile Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching the player profile.",
      });
    }
  },
};

export default command;