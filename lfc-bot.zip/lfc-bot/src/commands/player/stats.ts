import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { playerService } from "../../services/playerService.js";
import { formatSeasonStats } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("player")
    .setDescription("Player commands")
    .addSubcommand((sub) =>
      sub
        .setName("stats")
        .setDescription("View a player's detailed career statistics")
        .addUserOption((opt) =>
          opt
            .setName("player")
            .setDescription("The player to view stats for")
            .setRequired(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const targetUser = interaction.options.getUser("player", true);

    try {
      const player = await playerService.getPlayer(targetUser.id);

      if (!player) {
        await interaction.editReply({
          content: `❌ ${targetUser.username} is not registered as an LFC player.`,
        });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle(`📊 ${targetUser.username} — Career Statistics`)
        .setThumbnail(targetUser.displayAvatarURL())
        .setColor("#00AA00");

      // Per-season breakdown
      if (player.seasonStats.length > 0) {
        for (const stat of player.seasonStats) {
          embed.addFields({
            name: `📅 ${stat.season.name}`,
            value: formatSeasonStats({
              goals: stat.goals,
              assists: stat.assists,
              mvps: stat.mvps,
              appearances: stat.appearances,
              yellowCards: stat.yellowCards,
              redCards: stat.redCards,
            }),
            inline: true,
          });
        }
      } else {
        embed.addFields({
          name: "No Season Data",
          value: "This player hasn't recorded any stats yet.",
          inline: false,
        });
      }

      // Career totals
      embed.addFields({
        name: "🏆 Career Totals",
        value: formatSeasonStats({
          goals: player.goals,
          assists: player.assists,
          mvps: player.mvps,
          appearances: player.appearances,
          yellowCards: player.yellowCards,
          redCards: player.redCards,
        }),
        inline: false,
      });

      embed.setFooter({ text: "Legacy Football Championship" }).setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Player Stats Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching player stats.",
      });
    }
  },
};

export default command;