import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { prisma } from "../../database/prisma.js";
import { teamService } from "../../services/teamService.js";
import { newsService } from "../../services/newsService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command, ExtendedClient } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("transfer")
    .setDescription("Transfer commands")
    .addSubcommand((sub) =>
      sub
        .setName("complete")
        .setDescription("Complete a pending transfer")
        .addStringOption((opt) =>
          opt
            .setName("transfer_id")
            .setDescription("Transfer ID to complete")
            .setRequired(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only **Founder** or **League Management** can complete transfers."
          ),
        ],
      });
      return;
    }

    const transferId = interaction.options.getString("transfer_id", true);

    try {
      const transfer = await prisma.transfer.findUnique({
        where: { id: transferId },
        include: { player: { include: { user: true } } },
      });

      if (!transfer) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Transfer Not Found", `Transfer ID **${transferId}** not found.`)],
        });
        return;
      }

      if (transfer.status !== "Pending") {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Invalid Status", `This transfer is already **${transfer.status}**.`)],
        });
        return;
      }

      // Update the player's team
      if (transfer.toTeamId) {
        await teamService.addPlayerToTeam(transfer.playerId, transfer.toTeamId);
      } else {
        await teamService.removePlayerFromTeam(transfer.playerId);
      }

      // Mark transfer as completed
      await prisma.transfer.update({
        where: { id: transferId },
        data: {
          status: "Completed",
          completedAt: new Date(),
        },
      });

      // ── Auto-post transfer news ──
      try {
        if (interaction.guild) {
          await newsService.announceTransfer(
            interaction.client as ExtendedClient,
            {
              guildId: interaction.guild.id,
              playerName: transfer.player.user.username,
              fromTeam: transfer.fromTeamName ?? "Free Agent",
              toTeam: transfer.toTeamName ?? "Free Agent",
              fee: transfer.fee ? `$${transfer.fee}M` : undefined,
            }
          );
        }
      } catch (newsError) {
        console.error("[Transfer News Error]", newsError);
        // Non-fatal
      }

      const embed = new EmbedBuilder()
        .setTitle("✅ Transfer Completed!")
        .setColor("#00AA00")
        .addFields(
          { name: "👤 Player", value: transfer.player.user.username, inline: true },
          { name: "➡️ From", value: transfer.fromTeamName ?? "Free Agent", inline: true },
          { name: "🏠 To", value: transfer.toTeamName ?? "Free Agent", inline: true },
          { name: "💰 Fee", value: transfer.fee ? `$${transfer.fee}M` : "Free Transfer", inline: true }
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Transfer Complete Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while completing the transfer.",
      });
    }
  },
};

export default command;