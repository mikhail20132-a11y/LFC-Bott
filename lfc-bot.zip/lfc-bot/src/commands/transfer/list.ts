import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { prisma } from "../../database/prisma.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("transfers")
    .setDescription("View recent completed transfers"),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    try {
      const transfers = await prisma.transfer.findMany({
        where: { status: "Completed" },
        include: {
          player: { include: { user: true } },
        },
        orderBy: { completedAt: "desc" },
        take: 10,
      });

      if (transfers.length === 0) {
        await interaction.editReply({
          content: "📋 No completed transfers yet.",
        });
        return;
      }

      const embed = new EmbedBuilder()
        .setTitle("🔄 Recent Transfers")
        .setColor("#00AA00")
        .setDescription(
          transfers
            .map(
              (t, i) =>
                `${i + 1}. **${t.player.user.username}**` +
                `: ${t.fromTeamName ?? "Free Agent"} → ${t.toTeamName ?? "Free Agent"}` +
                (t.fee ? ` ($${t.fee}M)` : " (Free)")
            )
            .join("\n")
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Transfers List Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching transfers.",
      });
    }
  },
};

export default command;