import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { prisma } from "../../database/prisma.js";
import { playerService } from "../../services/playerService.js";
import { teamService } from "../../services/teamService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("transfer")
    .setDescription("Transfer management commands")
    .addSubcommand((sub) =>
      sub
        .setName("create")
        .setDescription("Create a transfer request (Management only)")
        .addUserOption((opt) =>
          opt
            .setName("player")
            .setDescription("Player to transfer")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("to_team")
            .setDescription("Destination team")
            .setRequired(true)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("fee")
            .setDescription("Transfer fee (in millions)")
            .setRequired(false)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "Only **Founder** or **League Management** can create transfers."
          ),
        ],
      });
      return;
    }

    const targetUser = interaction.options.getUser("player", true);
    const toTeamName = interaction.options.getString("to_team", true);
    const fee = interaction.options.getInteger("fee");

    try {
      const player = await playerService.getPlayer(targetUser.id);
      if (!player) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Player Not Found", `${targetUser.username} is not registered.`)],
        });
        return;
      }

      const toTeam = await teamService.getTeamByName(toTeamName);
      if (!toTeam) {
        await interaction.editReply({
          embeds: [createErrorEmbed("❌ Team Not Found", `Team **${toTeamName}** not found.`)],
        });
        return;
      }

      const transfer = await prisma.transfer.create({
        data: {
          playerId: player.id,
          fromTeamId: player.teamId,
          fromTeamName: player.team?.name ?? "Free Agent",
          toTeamId: toTeam.id,
          toTeamName: toTeam.name,
          fee,
          status: "Pending",
        },
      });

      const embed = new EmbedBuilder()
        .setTitle("🔄 Transfer Request Created")
        .setColor("#FFAA00")
        .addFields(
          { name: "👤 Player", value: `<@${targetUser.id}>`, inline: true },
          { name: "➡️ Destination", value: toTeam.name, inline: true },
          { name: "💰 Fee", value: fee ? `$${fee}M` : "Free Transfer", inline: true },
          { name: "📋 Status", value: "⏳ Pending", inline: true },
          { name: "🔢 Transfer ID", value: transfer.id.slice(0, 8), inline: true }
        )
        .setFooter({ text: "Use /transfer complete to finalize" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Transfer Create Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while creating the transfer.",
      });
    }
  },
};

export default command;