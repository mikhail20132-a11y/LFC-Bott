import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { teamService } from "../../services/teamService.js";
import type { Command } from "../../types/index.js";
import type { Position } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("team")
    .setDescription("Team commands")
    .addSubcommand((sub) =>
      sub
        .setName("roster")
        .setDescription("View a team's full roster")
        .addStringOption((opt) =>
          opt
            .setName("name")
            .setDescription("Team name")
            .setRequired(true)
            .setAutocomplete(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const teamName = interaction.options.getString("name", true);

    try {
      const team = await teamService.getTeamByName(teamName);

      if (!team) {
        await interaction.editReply({
          content: `❌ Team **${teamName}** not found.`,
        });
        return;
      }

      const positions: Position[] = [
        "Goalkeeper",
        "Defender",
        "Midfielder",
        "Forward",
      ];

      const embed = new EmbedBuilder()
        .setTitle(`👥 ${team.name} — Squad Roster`)
        .setColor("#00AA00");

      let totalPlayers = 0;

      for (const pos of positions) {
        const positionPlayers = team.players.filter(
          (p) => p.position === pos
        );

        if (positionPlayers.length > 0) {
          totalPlayers += positionPlayers.length;
          embed.addFields({
            name: `${getPositionEmoji(pos)} ${pos}s (${positionPlayers.length})`,
            value: positionPlayers
              .map(
                (p) =>
                  `**${p.user.username}** — ⚽ ${p.goals}G / 🎯 ${p.assists}A / 🏆 ${p.mvps} MVP`
              )
              .join("\n"),
            inline: false,
          });
        } else {
          embed.addFields({
            name: `${getPositionEmoji(pos)} ${pos}s`,
            value: "No players",
            inline: true,
          });
        }
      }

      embed.setFooter({
        text: `Total: ${totalPlayers} players | Legacy Football Championship`,
      });
      embed.setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Team Roster Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching the roster.",
      });
    }
  },
};

function getPositionEmoji(position: Position): string {
  switch (position) {
    case "Goalkeeper":
      return "🧤";
    case "Defender":
      return "🛡️";
    case "Midfielder":
      return "🎯";
    case "Forward":
      return "⚽";
    default:
      return "👤";
  }
}

export default command;