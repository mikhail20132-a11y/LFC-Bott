import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { teamService } from "../../services/teamService.js";
import { playerService } from "../../services/playerService.js";
import { hasRole, RoleType } from "../../utils/permissions.js";
import { createErrorEmbed } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("team")
    .setDescription("Team management commands")
    .addSubcommand((sub) =>
      sub
        .setName("create")
        .setDescription("Create a new team (Management only)")
        .addStringOption((opt) =>
          opt
            .setName("name")
            .setDescription("Full team name (e.g. Legacy FC)")
            .setRequired(true)
        )
        .addStringOption((opt) =>
          opt
            .setName("short")
            .setDescription("Short name (e.g. LFC)")
            .setRequired(false)
        )
        .addStringOption((opt) =>
          opt
            .setName("description")
            .setDescription("Team description")
            .setRequired(false)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    // Permission check
    const member = interaction.member;
    if (
      !hasRole(member as never, RoleType.Founder) &&
      !hasRole(member as never, RoleType.LeagueManagement)
    ) {
      await interaction.editReply({
        embeds: [
          createErrorEmbed(
            "❌ Insufficient Permissions",
            "You need the **Founder** or **League Management** role to create teams."
          ),
        ],
      });
      return;
    }

    const name = interaction.options.getString("name", true);
    const shortName = interaction.options.getString("short");
    const description = interaction.options.getString("description");
    const managerId = interaction.user.id;

    try {
      // Ensure user exists in DB
      await playerService.getOrCreatePlayer(managerId, interaction.user.username);

      // Check if team name is taken
      const existing = await teamService.getTeamByName(name);
      if (existing) {
        await interaction.editReply({
          embeds: [
            createErrorEmbed(
              "❌ Team Already Exists",
              `A team named **${name}** already exists.`
            ),
          ],
        });
        return;
      }

      const team = await teamService.createTeam({
        name,
        shortName: shortName ?? undefined,
        description: description ?? undefined,
        managerId,
      });

      const embed = new EmbedBuilder()
        .setTitle(`✅ Team Created: ${team.name}`)
        .setColor("#00AA00")
        .addFields(
          { name: "📛 Name", value: team.name, inline: true },
          {
            name: "🔤 Short Name",
            value: team.shortName ?? "None",
            inline: true,
          },
          {
            name: "👤 Manager",
            value: `<@${team.manager.discordId}>`,
            inline: true,
          },
          {
            name: "📝 Description",
            value: team.description ?? "No description.",
            inline: false,
          }
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Team Create Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while creating the team.",
      });
    }
  },
};

export default command;