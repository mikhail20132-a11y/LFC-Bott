import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { teamService } from "../../services/teamService.js";
import { leagueService } from "../../services/leagueService.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("team")
    .setDescription("Team commands")
    .addSubcommand((sub) =>
      sub
        .setName("stats")
        .setDescription("View detailed team statistics")
        .addStringOption((opt) =>
          opt
            .setName("name")
            .setDescription("Team name")
            .setRequired(true)
            .setAutocomplete(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const teamName = interaction.options.getString("name", true);

    try {
      const team = await teamService.getTeamByName(teamName);

      if (!team) {
        await interaction.editReply({
          content: `❌ Team **${teamName}** not found.`,
        });
        return;
      }

      const activeSeason = await leagueService.getActiveSeason();

      const embed = new EmbedBuilder()
        .setTitle(`📊 ${team.name} — Statistics`)
        .setColor("#00AA00");

      // Season-by-season breakdown
      if (team.seasonTeams.length > 0) {
        for (const stat of team.seasonTeams) {
          const gd = stat.goalsFor - stat.goalsAgainst;
          const gdText = gd >= 0 ? `+${gd}` : `${gd}`;
          embed.addFields({
            name: `📅 ${stat.season?.name ?? "Unknown Season"}`,
            value: [
              `**Played:** ${stat.played}`,
              `**Wins:** ${stat.wins}`,
              `**Draws:** ${stat.draws}`,
              `**Losses:** ${stat.losses}`,
              `**GF:** ${stat.goalsFor} | **GA:** ${stat.goalsAgainst} | **GD:** ${gdText}`,
              `**Points:** ${stat.points} (${((stat.points / (stat.played * 3)) * 100).toFixed(1)}% win rate)`,
            ].join("\n"),
            inline: true,
          });
        }
      } else {
        embed.addFields({
          name: "No Season Data",
          value: "This team hasn't played any matches yet.",
          inline: false,
        });
      }

      // Player contributions
      const topScorer = [...team.players].sort((a, b) => b.goals - a.goals)[0];
      const topAssist = [...team.players].sort(
        (a, b) => b.assists - a.assists
      )[0];
      const topMvp = [...team.players].sort((a, b) => b.mvps - a.mvps)[0];

      embed.addFields({
        name: "🌟 Key Players",
        value: [
          `⚽ **Top Scorer:** ${topScorer ? `${topScorer.user.username} (${topScorer.goals}G)` : "N/A"}`,
          `🎯 **Top Assists:** ${topAssist ? `${topAssist.user.username} (${topAssist.assists}A)` : "N/A"}`,
          `🏆 **Most MVPs:** ${topMvp ? `${topMvp.user.username} (${topMvp.mvps})` : "N/A"}`,
        ].join("\n"),
        inline: false,
      });

      embed
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Team Stats Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching team stats.",
      });
    }
  },
};

export default command;