import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { teamService } from "../../services/teamService.js";
import { formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("team")
    .setDescription("Team commands")
    .addSubcommand((sub) =>
      sub
        .setName("info")
        .setDescription("View team information")
        .addStringOption((opt) =>
          opt
            .setName("name")
            .setDescription("Team name")
            .setRequired(true)
            .setAutocomplete(true)
        )
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const teamName = interaction.options.getString("name", true);

    try {
      const team = await teamService.getTeamByName(teamName);

      if (!team) {
        await interaction.editReply({
          content: `❌ Team **${teamName}** not found.`,
        });
        return;
      }

      // Get current season stats
      const seasonStats = team.seasonTeams[team.seasonTeams.length - 1];

      const embed = new EmbedBuilder()
        .setTitle(`🏟️ ${team.name} ${team.shortName ? `(${team.shortName})` : ""}`)
        .setColor("#00AA00")
        .addFields(
          {
            name: "👤 Manager",
            value: `<@${team.manager.discordId}>`,
            inline: true,
          },
          {
            name: "👥 Squad Size",
            value: `${team.players.length} players`,
            inline: true,
          },
          {
            name: "🏆 Trophies",
            value: `${team.trophies}`,
            inline: true,
          },
          {
            name: "📝 Description",
            value: team.description ?? "No description set.",
            inline: false,
          }
        );

      // Add season stats if available
      if (seasonStats) {
        embed.addFields({
          name: `📊 Season Record (${seasonStats.season?.name ?? "Current"})`,
          value: [
            `**Played:** ${seasonStats.played}`,
            `**Wins:** ${seasonStats.wins}`,
            `**Draws:** ${seasonStats.draws}`,
            `**Losses:** ${seasonStats.losses}`,
            `**Goals For:** ${seasonStats.goalsFor}`,
            `**Goals Against:** ${seasonStats.goalsAgainst}`,
            `**GD:** ${seasonStats.goalsFor - seasonStats.goalsAgainst}`,
            `**Points:** ${seasonStats.points}`,
          ].join(" | "),
          inline: false,
        });
      }

      // Top 5 players by goals
      const topScorers = [...team.players]
        .sort((a, b) => b.goals - a.goals)
        .slice(0, 5);

      if (topScorers.length > 0) {
        embed.addFields({
          name: "⚽ Top Scorers",
          value: topScorers
            .map(
              (p, i) =>
                `${i + 1}. **${p.user.username}** — ${p.goals}G / ${p.assists}A`
            )
            .join("\n"),
          inline: false,
        });
      }

      embed
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Team Info Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching team info.",
      });
    }
  },
};

export default command;