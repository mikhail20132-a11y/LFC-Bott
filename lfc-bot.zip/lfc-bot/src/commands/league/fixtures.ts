import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import { leagueService } from "../../services/leagueService.js";
import { formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("fixtures")
    .setDescription("View upcoming match fixtures"),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    try {
      const activeSeason = await leagueService.getActiveSeason();
      const fixtures = await matchService.getUpcomingFixtures(10);

      const embed = new EmbedBuilder()
        .setTitle("📅 Upcoming Fixtures")
        .setColor("#00AA00");

      if (fixtures.length > 0) {
        for (const match of fixtures) {
          embed.addFields({
            name: `${match.homeTeam.name} vs ${match.awayTeam.name}`,
            value: [
              `📅 **Date:** ${formatDate(match.matchDate)}`,
              `📊 **Season:** ${match.season.name}`,
              match.refereeId ? `👨‍⚖️ **Referee:** <@${match.refereeId}>` : null,
            ]
              .filter(Boolean)
              .join("\n"),
            inline: false,
          });
        }
      } else {
        embed.setDescription(
          activeSeason
            ? "No upcoming fixtures scheduled."
            : "No active season. Start a season first!"
        );
      }

      embed
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Fixtures Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching fixtures.",
      });
    }
  },
};

export default command;