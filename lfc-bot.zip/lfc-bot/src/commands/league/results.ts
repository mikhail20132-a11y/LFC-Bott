import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("results")
    .setDescription("View recent match results"),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    try {
      const results = await matchService.getRecentResults(10);

      const embed = new EmbedBuilder()
        .setTitle("📋 Recent Results")
        .setColor("#00AA00");

      if (results.length > 0) {
        for (const match of results) {
          const homeWin = match.homeScore > match.awayScore;
          const awayWin = match.awayScore > match.homeScore;
          const scoreEmoji = homeWin ? "🏠" : awayWin ? "🚗" : "🤝";

          // Get scorers if available
          const scorers = match.goals
            .slice(0, 3)
            .map((g) => g.player.user.username)
            .join(", ");

          // Get MVP if available
          const mvp = match.mvps[0];

          embed.addFields({
            name: `${scoreEmoji} ${match.homeTeam.name} ${match.homeScore} - ${match.awayScore} ${match.awayTeam.name}`,
            value: [
              `📅 ${match.matchDate ? new Date(match.matchDate).toLocaleDateString() : "N/A"}`,
              scorers ? `⚽ **Scorers:** ${scorers}` : null,
              mvp ? `🏆 **MVP:** ${mvp.player.user.username}` : null,
            ]
              .filter(Boolean)
              .join("\n"),
            inline: false,
          });
        }
      } else {
        embed.setDescription("No match results yet.");
      }

      embed
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Results Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching results.",
      });
    }
  },
};

export default command;