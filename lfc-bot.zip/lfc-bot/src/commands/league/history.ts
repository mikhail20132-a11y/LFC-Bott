import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { matchService } from "../../services/matchService.js";
import { formatDate } from "../../utils/helpers.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("history")
    .setDescription("View match history between two teams")
    .addStringOption((opt) =>
      opt
        .setName("team1")
        .setDescription("First team name")
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("team2")
        .setDescription("Second team name")
        .setRequired(true)
    ),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    const team1Name = interaction.options.getString("team1", true);
    const team2Name = interaction.options.getString("team2", true);

    try {
      const teamService = await import("../../services/teamService.js").then(
        (m) => m.teamService
      );

      const team1 = await teamService.getTeamByName(team1Name);
      const team2 = await teamService.getTeamByName(team2Name);

      if (!team1 || !team2) {
        await interaction.editReply({
          content: "❌ One or both teams not found.",
        });
        return;
      }

      const matches = await matchService.getTeamMatches(team1.id);
      const headToHead = matches.filter(
        (m) =>
          (m.homeTeamId === team1.id && m.awayTeamId === team2.id) ||
          (m.homeTeamId === team2.id && m.awayTeamId === team1.id)
      );

      if (headToHead.length === 0) {
        await interaction.editReply({
          content: `📋 **${team1.name}** and **${team2.name}** have no match history.`,
        });
        return;
      }

      // Calculate head-to-head record
      let team1Wins = 0;
      let team2Wins = 0;
      let draws = 0;
      let team1Goals = 0;
      let team2Goals = 0;

      for (const m of headToHead) {
        if (m.status !== "Finished") continue;
        const isTeam1Home = m.homeTeamId === team1.id;
        const t1Score = isTeam1Home ? m.homeScore : m.awayScore;
        const t2Score = isTeam1Home ? m.awayScore : m.homeScore;

        team1Goals += t1Score;
        team2Goals += t2Score;

        if (t1Score > t2Score) team1Wins++;
        else if (t2Score > t1Score) team2Wins++;
        else draws++;
      }

      const embed = new EmbedBuilder()
        .setTitle(`📊 Head-to-Head: ${team1.name} vs ${team2.name}`)
        .setColor("#00AA00")
        .addFields(
          {
            name: `🏠 ${team1.name}`,
            value: `${team1Wins} wins | ${team1Goals} goals`,
            inline: true,
          },
          { name: "🤝 Draws", value: `${draws}`, inline: true },
          {
            name: `🚗 ${team2.name}`,
            value: `${team2Wins} wins | ${team2Goals} goals`,
            inline: true,
          },
          {
            name: `📋 Last ${Math.min(headToHead.length, 5)} Meetings`,
            value: headToHead
              .slice(0, 5)
              .map((m) => {
                const isTeam1Home = m.homeTeamId === team1.id;
                const t1Score = isTeam1Home ? m.homeScore : m.awayScore;
                const t2Score = isTeam1Home ? m.awayScore : m.homeScore;
                return `${formatDate(m.matchDate)}: ${team1.name} ${t1Score} - ${t2Score} ${team2.name}`;
              })
              .join("\n"),
            inline: false,
          }
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[History Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching history.",
      });
    }
  },
};

export default command;