import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
} from "discord.js";
import { leagueService } from "../../services/leagueService.js";
import type { Command } from "../../types/index.js";

const command: Command = {
  data: new SlashCommandBuilder()
    .setName("standings")
    .setDescription("View the current league table"),

  async execute(interaction: CommandInteraction) {
    if (!interaction.isChatInputCommand()) return;
    await interaction.deferReply();

    try {
      const activeSeason = await leagueService.getActiveSeason();

      if (!activeSeason) {
        await interaction.editReply({
          content: "❌ No active season. Use `/season start` to begin a season.",
        });
        return;
      }

      const standings = await leagueService.getStandings(activeSeason.id);

      const embed = new EmbedBuilder()
        .setTitle(`🏆 ${activeSeason.name} — League Standings`)
        .setColor("#00AA00")
        .setDescription(
          standings.length > 0
            ? standings
                .map(
                  (s) =>
                    `**${s.position}.** ${getPositionEmoji(s.position)} **${s.teamName}**` +
                    `\n    ${s.played}PL | ${s.wins}W | ${s.draws}D | ${s.losses}L` +
                    ` | GF:${s.goalsFor} GA:${s.goalsAgainst} GD:${s.goalDifference >= 0 ? "+" : ""}${s.goalDifference}` +
                    ` | **${s.points}pts**`
                )
                .join("\n\n")
            : "No standings data yet. Start the season and play matches!"
        )
        .setFooter({ text: "Legacy Football Championship" })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("[Standings Error]", error);
      await interaction.editReply({
        content: "❌ An error occurred while fetching standings.",
      });
    }
  },
};

function getPositionEmoji(pos: number): string {
  switch (pos) {
    case 1:
      return "🥇";
    case 2:
      return "🥈";
    case 3:
      return "🥉";
    default:
      return "#";
  }
}

export default command;