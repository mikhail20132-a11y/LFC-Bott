import { Client, GatewayIntentBits, Collection, Events } from "discord.js";
import "dotenv/config";
import { prisma } from "./database/prisma.js";
import { loadCommands } from "./utils/commandLoader.js";
import { loadEvents } from "./utils/eventLoader.js";
import type { ExtendedClient } from "./types/index.js";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
}) as ExtendedClient;

client.commands = new Collection();

async function bootstrap() {
  try {
    // Connect to database
    await prisma.$connect();
    console.log("[Database] Connected to PostgreSQL successfully.");

    // Load commands
    await loadCommands(client);
    console.log("[Commands] All commands loaded.");

    // Load events
    await loadEvents(client);
    console.log("[Events] All events loaded.");

    // Login to Discord
    await client.login(process.env.DISCORD_TOKEN);
    console.log(`[Bot] Logged in as ${client.user?.tag}`);
  } catch (error) {
    console.error("[Fatal] Failed to start bot:", error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on("SIGINT", async () => {
  console.log("\n[Shutdown] Shutting down gracefully...");
  await prisma.$disconnect();
  client.destroy();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  console.log("\n[Shutdown] Shutting down gracefully...");
  await prisma.$disconnect();
  client.destroy();
  process.exit(0);
});

bootstrap();