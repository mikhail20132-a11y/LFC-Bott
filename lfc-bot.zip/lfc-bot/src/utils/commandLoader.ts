import { readdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import type { ExtendedClient, Command } from "../types/index.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export async function loadCommands(client: ExtendedClient): Promise<void> {
  const commandsPath = join(__dirname, "..", "commands");
  const categories = readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = join(commandsPath, category);
    const stat = await import("fs").then((fs) => fs.promises.stat(categoryPath));

    if (!stat.isDirectory()) continue;

    const commandFiles = readdirSync(categoryPath).filter(
      (file) => file.endsWith(".ts") || file.endsWith(".js")
    );

    for (const file of commandFiles) {
      const filePath = join(categoryPath, file);
      try {
        const commandModule = await import(filePath);
        const command = commandModule.default as Command;

        if (!command?.data?.name || !command?.execute) {
          console.warn(`[Warning] Command at ${filePath} missing "data" or "execute".`);
          continue;
        }

        client.commands.set(command.data.name, command);
        console.log(`[Commands] Loaded /${command.data.name} (${category})`);
      } catch (error) {
        console.error(`[Error] Failed to load command at ${filePath}:`, error);
      }
    }
  }
}